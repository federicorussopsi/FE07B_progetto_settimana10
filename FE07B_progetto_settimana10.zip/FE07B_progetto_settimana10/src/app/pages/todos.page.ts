import { Component, OnInit } from '@angular/core';
import { Todo } from '../models/todo';
import * as TodoServizio from '../todos.service'

@Component({
  template: `
    <div class="container">
      <p>Ops, non ci sono task!</p>
      <ul>
        <li *ngFor="let item of todos; let i = index">
          {{ item.title }} <button (click)="aggiorna(item, i)">✅</button>
        </li>
      </ul>
    </div>
    <div>
      <input type="text" [(ngModel)]="todo" />
      <button (click)="aggiungi()" id="btn">Aggiungi task</button>
    </div>
  `,
  styles: [
    `.container {
      margin: 0 auto;
    }
    p {
      color: red;
    }
    #btn {
      background-color: blue;
      color: white;
      border-radius: 15px;
      font-weight: bold;
      padding: 5px;
    }`
  ],
})
export class TodosPage {
  i!: number;
  todo = '';
  todos!: Todo[];

  constructor() {
    TodoServizio.get().then((todos) => {
      this.todos = todos;
    });
  }

  aggiungi() {
    TodoServizio.add(this.todo).then((todos) => {
      console.log(todos);
      this.todo = '';
    });
  }

  async aggiorna(todo:Todo,i:number){
    await TodoServizio.update({completed:true},todo.id)
    this.todos.splice(i,1)
  }
}


