import { Component, OnInit } from '@angular/core';
import { TodosPage } from './todos.page';
import { Todo } from '../models/todo';
import * as TodoServizio from '../todos.service';

@Component({
  template: `
    <div>
      <ng-container  *ngIf="tasks; else elseTemplate">
        <div *ngIf="tasks.length > 0; else elseNoTask">
          <div *ngFor="let task of tasks; let i = index">
            <div>- {{ task.title }}</div>
          </div>
        </div>
      </ng-container>
      <ng-template #elseTemplate>
        <p>Recupero i task...</p>
      </ng-template>
    </div>
    <ng-template #elseNoTask> <p>Non ci sono task completati, qui 📝</p> </ng-template>
  `,
  styles: [],
})
export class CompletedPage {
  tasks!: Todo[];

  newTaskTitle: string | undefined;
  constructor() {
    TodoServizio.get().then((todos) => (this.tasks = todos.filter(todo => todo.completed)));
  }
}
